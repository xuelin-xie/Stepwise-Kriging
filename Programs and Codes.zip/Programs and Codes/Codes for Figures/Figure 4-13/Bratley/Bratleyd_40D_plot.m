clc;
figure(1)
plot(t1,'Marker','o','LineStyle','--',...
    'Color',[0.301960796117783 0.745098054409027 0.933333337306976],...
    'linewidth',3,'MarkerSize',9)
hold on
plot(t2,'Marker','square','LineStyle','--',...
    'Color',[0.929411768913269 0.694117665290833 0.125490203499794],...
    'linewidth',3,'MarkerSize',10)
hold on
xlim([0 11]);
set(gca,'FontSize',18,'XTick',[0 1 2 3 4 5 6 7 8 9 10 11]);
legend('Kriging','Stepwise-Kriging','Position',...
    [0.503563442479228 0.779353908828024 0.379289715201183 0.121860990457089],'FontSize',22)
title('Modeling time (Bratley function 40D)','FontSize',24)
xlabel('Number of iterations')
ylabel('Time (s)')


figure(2)
plot(RRmse1,'Marker','o','LineStyle','--',...
    'Color',[0.301960796117783 0.745098054409027 0.933333337306976],...
    'linewidth',3,'MarkerSize',9)
hold on
plot(RRmse2,'Marker','square','LineStyle','--',...
    'Color',[0.929411768913269 0.694117665290833 0.125490203499794],...
    'linewidth',3,'MarkerSize',10)
hold on
xlim([0 11]);
% legend('Kriging','Stepwise-Kriging')
legend('Kriging','Stepwise-Kriging','Position',...
    [0.503563442479228 0.779353908828024 0.379289715201183 0.121860990457089],'FontSize',22)
set(gca,'FontSize',18,'XTick',[0 1 2 3 4 5 6 7 8 9 10 11]);
title('RRMSE (Bratley function 40D)','FontSize',24)
xlabel('Number of iterations')
ylabel('RRMSE')

figure(3)
plot(RMAE1,'Marker','o','LineStyle','--',...
    'Color',[0.301960796117783 0.745098054409027 0.933333337306976],...
    'linewidth',3,'MarkerSize',9)
hold on
plot(RMAE2,'Marker','square','LineStyle','--',...
    'Color',[0.929411768913269 0.694117665290833 0.125490203499794],...
    'linewidth',3,'MarkerSize',10)
hold on
xlim([0 11]);
legend('Kriging','Stepwise-Kriging','Position',...
    [0.503563442479228 0.779353908828024 0.379289715201183 0.121860990457089],'FontSize',22)
set(gca,'FontSize',18,'XTick',[0 1 2 3 4 5 6 7 8 9 10 11]);
title('RMAE (Bratley function 40D)','FontSize',24)
xlabel('Number of iterations')
ylabel('RMAE')

% figure(4)
% A1=[1:3];
% data2=[mean(t1),mean(t2);mean(RRmse1),mean(RRmse2);mean(RMAE1),mean(RMAE2)];
% bar2=bar(A1,data2);
% set(bar2(1),'FaceColor',[0.301960796117783 0.745098054409027 0.933333337306976]);
% set(bar2(2),'FaceColor',[0.929411768913269 0.694117665290833 0.125490203499794]);
% xlabel('Number of iterations')
% ylabel('Time (s)');
% ylim([0 90]);
% legend('Kriging','Stepwise-Kriging','Position',...
%     [0.503563442479228 0.779353908828024 0.379289715201183 0.121860990457089],'FontSize',12)
% title('Modeling time (Bratley function 40D)','FontSize',13);

% figure(5)
% A=1;
% data1=[mean(t1),mean(t2)];
% bar1=bar(A,data1);
% set(bar1(1),'FaceColor',[0.301960796117783 0.745098054409027 0.933333337306976]);
% set(bar1(2),'FaceColor',[0.929411768913269 0.694117665290833 0.125490203499794]);
% set(gca,'xtick',[]);
% xlabel('Methods');
% ylabel('Time (s)');
% ylim([0 85]);
% legend('Kriging','Stepwise-Kriging','Position',...
%     [0.637043093455835 0.767261067450732 0.253990429209652 0.143173350330486],'FontSize',12)
% title('Means of the Modeling time (Bratley function 40D)','FontSize',13);

figure(4)
figure1 = figure(4);
A1=[1:3];
mt=mean(t1)+mean(t2);
mRRmse=mean(RRmse1)+mean(RRmse2);
mRMAE=mean(RMAE1)+mean(RMAE2);
data1=[mean(t1)/mt,mean(t2)/mt;mean(RRmse1)/mRRmse,mean(RRmse2)/mRRmse;...
    mean(RMAE1)/mRMAE,mean(RMAE2)/mRMAE]*100;
data2=roundn(data1,-2);
bar2=bar(A1,data2);
set(bar2(1),'FaceColor',[0.301960796117783 0.745098054409027 0.933333337306976]);
set(bar2(2),'FaceColor',[0.929411768913269 0.694117665290833 0.125490203499794]);
ylabel('Percentage (%)');
ylim([0 115]);
legend('Kriging','Stepwise-Kriging','Position',...
    [0.503563442479228 0.779353908828024 0.379289715201183 0.121860990457089],'FontSize',22)
set(gca,'FontSize',18,'XTickLabel',{'Time','RRMSE','RMAE'});
title('Mean percentage (Bratley function 40D)','FontSize',24);

% 创建 textbox
annotation(figure1,'textbox',...
    [0.185953711093375 0.646919131216504 0.0590582601755786 0.0330578512396694],...
    'String',data2(1,1),...
    'FontSize',14,...
    'FitBoxToText','off',...
    'EdgeColor','none');
annotation(figure1,'textbox',...
    [0.259377494014366 0.302211529009536 0.0590582601755786 0.0330578512396694],...
    'String',data2(1,2),...
    'FontSize',14,...
    'FitBoxToText','off',...
    'EdgeColor','none');
annotation(figure1,'textbox',...
    [0.4451316839585 0.473213006803618 0.0590582601755786 0.0330578512396696],...
    'String',data2(2,1),...
    'FontSize',14,...
    'FitBoxToText','off',...
    'EdgeColor','none');
annotation(figure1,'textbox',...
    [0.521548284118117 0.473155509369365 0.0590582601755786 0.0330578512396696],...
    'String',data2(2,2),...
    'FontSize',14,...
    'FitBoxToText','off',...
    'EdgeColor','none');
annotation(figure1,'textbox',...
    [0.70710295291301 0.472357019395333 0.0590582601755788 0.0330578512396691],...
    'String',data2(3,1),...
    'FontSize',14,...
    'FitBoxToText','off',...
    'EdgeColor','none');
annotation(figure1,'textbox',...
    [0.781524341580207 0.473703537950493 0.0590582601755785 0.0330578512396696],...
    'String',data2(3,2),...
    'FontSize',14,...
    'FitBoxToText','off',...
    'EdgeColor','none');

figure(5)
a1=[t1;RRmse1;RMAE1]';
a2=[t2;RRmse2;RMAE2]';
edgecolor1=[0,0,0]; % black color
edgecolor2=[0,0,0]; % black color
fillcolor1=[0.929411768913269 0.694117665290833 0.125490203499794];
fillcolor2=[0.301960796117783 0.745098054409027 0.933333337306976];
fillcolors=[repmat(fillcolor1,3,1);repmat(fillcolor2,3,1)];
position_1 = [0.75:1:2.75];  % define position for first boxplots
position_2 = [1.25:1:3.25];  % define position for second boxplots 
box_1 = boxplot(a1,'positions',position_1,'colors',edgecolor1,'width',0.3,'notch','on','symbol','r+','outliersize',5);
hold on;
box_2 = boxplot(a2,'positions',position_2,'colors',edgecolor2,'width',0.3,'notch','on','symbol','r+','outliersize',5);
boxobj = findobj(gca,'Tag','Box');
for j=1:length(boxobj)
    patch(get(boxobj(j),'XData'),get(boxobj(j),'YData'),fillcolors(j,:),'FaceAlpha',0.5);
end
set(gca,'FontSize',18,'XTick', [1 2 3],'XTickLabel',{'Time','RRMSE','RMAE'},'Xlim',[0.4 3.6]);
boxchi = get(gca, 'Children');
legend([boxchi(1),boxchi(4)], ["Kriging", "Stepwise-Kriging"],'FontSize',18);
title('Bratley function 40D','FontSize',24);

ST=[mean(t1),mean(t2),std(t1),std(t2),range(t1),range(t2)]

SRRMSE=[mean(RRmse1),mean(RRmse2),std(RRmse1),std(RRmse2),range(RRmse1),range(RRmse2)]

SRAE=[mean(RMAE1),mean(RMAE2),std(RMAE1),std(RMAE2),range(RMAE1),range(RMAE2)]
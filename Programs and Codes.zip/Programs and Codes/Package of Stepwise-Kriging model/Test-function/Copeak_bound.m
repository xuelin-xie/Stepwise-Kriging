function [lx,lu]= Copeak_bound
d = 50;
lx=0*ones(1,d);
lu=1*ones(1,d);
end
function [lx,lu]=Schwefel_bound
d=50;
lx=-50*ones(1,d);
lu=50*ones(1,d);

end
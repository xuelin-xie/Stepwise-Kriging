function [lx,lu]= prpeak_bound
d = 40;
lx=0*ones(1,d);
lu=1*ones(1,d);
end
function [lx,lu]= powell_bound
d=50;
lx=-4*ones(1,d);
lu=5*ones(1,d);
end
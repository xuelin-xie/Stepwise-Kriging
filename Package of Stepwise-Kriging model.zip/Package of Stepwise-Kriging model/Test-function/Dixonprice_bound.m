function [lx,lu]=Dixonprice_bound
d=70;
lx=-10*ones(1,d);
lu=10*ones(1,d);
end

function [lx,lu]= michal_bound
d=40;
lx=0*ones(1,d);
lu=pi*ones(1,d);
end
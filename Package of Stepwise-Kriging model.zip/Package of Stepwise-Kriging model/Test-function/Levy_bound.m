function [ XL,XU ] = Levy_bound(  )
%GP_BOUND Summary of this function goes here
%   Detailed explanation goes here
d=30;
XL=-10*ones(1,d);
XU=10*ones(1,d);

end


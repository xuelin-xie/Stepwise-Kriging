function [lx,lu]=Permd_bound
d=15;
lx=-d*ones(1,d);
lu=d*ones(1,d);
end